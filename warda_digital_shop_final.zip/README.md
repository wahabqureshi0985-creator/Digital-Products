# 🌸 Warda's Digital Shop

A modern, responsive website to sell digital products like ebooks, planners, and templates.

## 🔗 Live Site
https://yourusername.github.io/warda-digital-shop/

## 📦 Includes:
- 📘 Floral Notebook (your product)
- 📚 Ebooks
- 🗓️ Planners
- 🎨 Canva Templates

## 🛠️ Tech
- Pure HTML + CSS + JS (no framework)
- Mobile responsive
- PayPal Buy Now buttons
- Search bar & contact form

---

© 2025 Warda's Digital Shop
